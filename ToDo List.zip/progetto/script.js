let add_btn = document.getElementById("add_btn");

add_btn.addEventListener("click", function () {
    let task_txt = document.querySelector("#task_txt").value;       //selezione e lettura elementi
    let tasks_list_html = document.querySelector("#tasks_list_html");
                                                                    //creazione elemento
    var li = document.createElement('li');
    li.innerHTML = task_txt                                         //scrivi l'aggiunta all'interno
    li.classList.add('item')

    li.addEventListener("click", function () {
        li.remove()
        rimuoviElementodaDb(li)
    })
    //aggiunta definitiva elemento
    tasks_list_html.append(li)                                      //aggiungi in fondo alla lista
    document.querySelector('#task_txt').value = ''
    salvaDatiNelDb(task_txt)
})
function creaHTML() {
    var elementiSalvati = JSON.parse(localStorage.getItem('elementiSalvati'))
    let tasks_list_html = document.querySelector('tasks_list_html')
    elementiSalvati.forEach(function (li) {
                                                                   //creazione elemento
        var li = document.createElement('li');
        li.innerHTML = task_txt                                    //scrivi l'aggiunta all'interno
        li.classList.add('item')
        //aggiunta funzioni
        li.addEventListener("click", function () {
            li.remove()
            rimuoviElementodaDb()
        })
        //aggiunta def elemento
        tasks_list_html.prepend(li)
    });
}

//aggiornamento/salvataggio dati nel localstorage
function salvaDatiNelDb(task_txt) {
    if (localStorage.getItem('elementiSalvati') == null) {
        var db = [task_txt]
    } else {
        var db = JSON.parse(localStorage.getItem('elementiSalvati'))
        db.push(task_txt)
    }

    var ls = localStorage.getItem('elementiSalvati')
    var db = ls ? JSON.parse(ls) : []
    db.push(task_txt)

    localStorage.setItem('elementiSalvati', JSON.stringify(db))
}
//rimuove un elemento dal localstorage
function rimuoviElementodaDb(el) {

    let ls = localStorage.getItem('elementiSalvati')
    let db = JSON.parse(ls)

    let indiceElemento = db.indexOf(el.innerHTML)

    db.splice(indiceElemento, 1)

    localStorage.setItem('elementiSalvati', JSON.stringify(db))
}